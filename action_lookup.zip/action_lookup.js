"use strict";
kintone.events.on(['app.record.create.show','mobile.app.record.create.show'],function(event){
	return new kintone.Promise(function(resolve,reject){
		kintone.api(kintone.api.url('/k/v1/app/form/fields',true),'GET',{app:(event.type.match(/mobile/g))?kintone.mobile.app.getId():kintone.app.getId(),lang:'user'},function(resp){
			var lookups=[];
			var flatten=function(properties){
				for (var key in properties)
				{
					switch (properties[key].type)
					{
						case 'SUBTABLE':
							flatten(properties[key].fields);
							break;
						default:
							if ('lookup' in properties[key]) lookups.push(key);
							break;
					}
				}
			};
			var setup=function(record){
				for (var key in record)
				{
					switch (record[key].type)
					{
						case 'SUBTABLE':
							for (var i=0;i<record[key].value.length;i++) setup(record[key].value[i].value);
							break;
						default:
							if (lookups.includes(key))
								if (record[key].value) record[key].lookup=true
							break;
					}
				}
			};
			flatten(resp.properties);
			setup(event.record);
			resolve(event);
		},function(error){
			resolve(event);
		});
	});
});
