var queries=() => {
	var res={};
	if (window.location.search)
	{
		var hash=null;
		var hashes=window.location.search.substring(1).split('&');
		for(var i=0;i<hashes.length;i++)
		{
			hash=hashes[i].split('=');
			res[decodeURI(hash[0])]=decodeURI(hash[1]);
		}
	}
	return res;
};
var setup=(event,params,ismobile) => {
	return new kintone.Promise(function(resolve,reject){
		kintone.api(kintone.api.url('/k/v1/app/form/fields',true),'GET',{app:(ismobile)?kintone.mobile.app.getId():kintone.app.getId(),lang:'user'},function(resp){
			var fields=resp.properties;
			for (var key in params)
				if (key in fields)
					((field,value) => {
						switch (field.type)
						{
							case 'CHECK_BOX':
							case 'MULTI_SELECT':
								event.record[field.code].value=value.split(',');
								break;
							case 'DROP_DOWN':
							case 'DATE':
							case 'DATETIME':
							case 'LINK':
							case 'MULTI_LINE_TEXT':
							case 'NUMBER':
							case 'RADIO_BUTTON':
							case 'RICH_TEXT':
							case 'SINGLE_LINE_TEXT':
							case 'TIME':
								event.record[field.code].value=value;
								if ('lookup' in field)
									event.record[field.code].lookup=true;
								break;
						}
					})(fields[key],params[key]);
			resolve(event);
		});
	});
};
kintone.events.on('app.record.create.show',function(event){
	var params=queries();
	return (Object.keys(params)!=0)?setup(event,params,false):event;
});
kintone.events.on('mobile.app.record.create.show',function(event){
	var params=queries();
	return (Object.keys(params)!=0)?setup(event,params,true):event;
});
