"use strict";
(function(){
	/* 表示するボタンのテキストを変更したい場合は下記の「PC版を表示」という箇所を表示したいテキストに変更して下さい */
	var buttonlabel = 'PC版を表示';
	var events = [
		'mobile.app.record.detail.show',
		'mobile.app.record.create.show',
		'mobile.app.record.edit.show',
		'mobile.app.record.index.show',
		'mobile.portal.show'
	];
	kintone.events.on(events,function(event){
		var container = null;
		switch (event.type)
		{
			case 'mobile.app.record.detail.show':
			case 'mobile.app.record.create.show':
			case 'mobile.app.record.edit.show':
			case 'mobile.app.record.index.show':
				container=kintone.mobile.app.getHeaderSpaceElement();
				break;
			case 'mobile.portal.show':
				container=kintone.mobile.portal.getContentSpaceElement();
				break;
		}
		if (container)
		{
			(function(button){
				button.innerHTML = buttonlabel;
				button.classList.add('pc_view_button');
				button.onclick = function(){
					var url=window.location.href;
					url=url.replace(/\/m\//,'/');
					url=url.replace(/\?record/,'#record');
					url=url.replace(/#mode/,'&mode');
					url=url.replace(/&(prev|next|view|q)/g,'&l\.$1');
					window.open(url);
				};
				if (document.querySelector('.pc_view_button'))
					Array.from(document.querySelectorAll('.pc_view_button')).some(function(item,index){
						item.parentNode.removeChild(item);
					});
				container.appendChild(button);
			})(document.createElement('button'));
		}
		return event;
	});
})();
